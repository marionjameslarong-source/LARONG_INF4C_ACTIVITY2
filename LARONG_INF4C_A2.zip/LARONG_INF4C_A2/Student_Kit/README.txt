WST2 – Authentication, Authorization & Access Control
STUDENT KIT – Hands-On Activities 1 to 3
=====================================================

Start here: open WST2_Activities_Student_Handout.docx

Folders
-------
Activity1_Starter/wst2_auth   Copy into C:\xampp\htdocs\ (or C:\laragon\www\).
                              Finish the TODOs in register.php, login.php,
                              logout.php, dashboard.php and database/01_users_table.sql.

Activity2_Starter/wst2_auth   Copy its contents INTO your existing htdocs\wst2_auth
                              folder (replace includes\header.php when asked).
                              Run database\02_grades_table.sql.

Activity3_BugHunt/wst2_auth   Copy its contents INTO htdocs\wst2_auth.
                              Run database\03_posts_table.sql (run again to reset).
                              delete_post.php is the VULNERABLE file from Slide 28.

Activity3_BugHunt/Activity3_Writeup_Template.docx
                              Fill in, export to PDF, keep it to one page.

Requirements: XAMPP or Laragon (PHP 8+, MySQL/MariaDB), VS Code, a browser.
Test attacks ONLY on your own localhost copy.
