
<?php
// 403.php – ACTIVITY 2
// Friendly access-denied page.

require_once __DIR__ . '/includes/init.php';

if (http_response_code() !== 403) {
    http_response_code(403);
}

$pageTitle = '403 – Access denied';
require __DIR__ . '/includes/header.php';
?>

<section class="card narrow center">
    <p class="big-code">403</p>

    <h1>Access Denied</h1>

    <p>
        Sorry, you are not allowed to access this page.
        Please return to your dashboard.
    </p>

    <a class="button" href="<?= BASE_URL ?>/dashboard.php">
        Go back to dashboard
    </a>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
