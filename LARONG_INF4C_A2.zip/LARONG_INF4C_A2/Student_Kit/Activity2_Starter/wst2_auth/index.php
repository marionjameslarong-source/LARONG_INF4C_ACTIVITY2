
<?php
// index.php – send visitors to the right page.

require __DIR__ . '/includes/init.php';

header('Location: ' . (empty($_SESSION['user_id']) ? 'login.php' : 'dashboard.php'));
exit;
