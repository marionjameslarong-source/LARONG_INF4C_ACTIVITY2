-- =====================================================================
-- ACTIVITY 1 – Create the users table
-- 1. In phpMyAdmin, create a database named:  wst2_auth  (collation utf8mb4_unicode_ci)
-- 2. Complete the CREATE TABLE statement below, then run it in the SQL tab.
-- =====================================================================

-- CREATE DATABASE wst2_auth CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE wst2_auth;

CREATE TABLE users (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,

    -- TODO: username – max 30 characters, required, and must be UNIQUE
    username        VARCHAR(30) NOT NULL UNIQUE,

    -- TODO: email – required, and should also be UNIQUE
    email           VARCHAR(255) NOT NULL UNIQUE,

    -- TODO: password_hash – VARCHAR(255), required
    --        (Why 255? password_hash() output can grow when PHP changes its algorithm.)
    password_hash   VARCHAR(255) NOT NULL,

    -- TODO: role – ENUM('admin','instructor','student'), required, DEFAULT 'student'
    --        (Default to the LEAST privilege. You will use this column in Activity 2.)
    role            ENUM('admin','instructor','student') NOT NULL DEFAULT 'student',

    -- TODO: created_at – TIMESTAMP that defaults to the current time
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    -- BONUS (account lockout):
    -- TODO: failed_attempts – small number, default 0
    failed_attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
    
    -- TODO: locked_until    – DATETIME, can be NULL
    locked_until    DATETIME DEFAULT NULL

) ENGINE=InnoDB;

-- DELIVERABLE: after testing, export this table
-- (phpMyAdmin > wst2_auth > users > Export > SQL) and include the .sql file.